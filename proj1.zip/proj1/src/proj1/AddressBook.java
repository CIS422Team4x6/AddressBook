package proj1;

public abstract class AddressBook {


abstract void InsertData(String name, String email, String street, String city, String state, int zip);
abstract void EditData();
abstract void DeleteData(int id);
abstract void SortbyName();
abstract void SortbyZip();
abstract void SaveasFile();
abstract void SelectAll();
}