package proj1;

public class Application {
	public static void main(String[] args) {
		EditAB testAb = new EditAB("test.db");
		testAb.InsertData("zzz","b","c","d","Finished Goods", 1111);
		testAb.InsertData("aa","bb","cc","dd","Finished Goods", 2222);
		testAb.InsertData("ccc","bbb","ccc","ddd","fff", 4444);
		testAb.InsertData("bbb","bbb","ccc","ddd","fff", 3333);

		testAb.SelectAll();
		testAb.SortbyName();
		testAb.SelectAll();

	}
}
