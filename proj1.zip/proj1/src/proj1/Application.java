package proj1;

public class Application {
	public static void main(String[] args) {
		EditAB testAb = new EditAB("test.tsv");
		testAb.InsertData("zzz","b","c","d","Finished Goods", 1111);
		testAb.InsertData("aa","bb","cc","dd","Finished Goods", 2222);
		testAb.InsertData("ccc","rrrr","ccc","ddd","fff", 4444);
		testAb.InsertData("bbb","bbb","ccc","ddd","fff", 3333);
		testAb.InsertData("bbb","bbb","ccc","ddd","fff", 555);
		testAb.InsertData("bbb","bbb","sss","ddd","fff", 7);
		testAb.InsertData("bbb","b2","ccc","k3","fff", 666);

/*		testAb.SelectAll();
		testAb.DeleteData(2);
		testAb.SelectAll();
		testAb.InsertData("fff", "fff", "fff", "fff", "fff", 0000);
		testAb.SelectAll();
*/
		//testAb.Search("fin");
		testAb.Search("k");
		testAb.Search("s");
		testAb.Search("1");
		testAb.Search("3");
		//testAb.SelectAll();
		//testAb.SortbyName();
		
	}
}
