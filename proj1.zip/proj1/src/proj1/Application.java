package proj1;

public class Application {
	public static void main(String[] args) {
		EditAB testAb = new EditAB("test.db");
		testAb.InsertData("a","b","c","d","Finished Goods", 5000);
		testAb.InsertData("aa","bb","cc","dd","Finished Goods", 1000);
		testAb.SelectAll();	
		testAb.DeleteData(1);
	}
}
